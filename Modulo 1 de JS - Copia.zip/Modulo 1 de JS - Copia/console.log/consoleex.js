

console.log(`Meu nome é "NOME".Estou aprendendo JavaScript às`, 10, "da manhã")