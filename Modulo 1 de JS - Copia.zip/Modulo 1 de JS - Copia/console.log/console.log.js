
console.log('nome') //exibir texto string = texto
console.log("nome") //exibir texto
console.log(`nome`) //exibir texto

console.log(123456, 15.85, "nome") //number = numero