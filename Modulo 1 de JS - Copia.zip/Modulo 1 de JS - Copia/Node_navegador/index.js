

console.log("Olá Mundo!")
console.log("Este trecho será exibido no console do navegador")
alert('ola mundo')