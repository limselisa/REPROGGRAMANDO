//Não podemos criar constatnes com palavras reservadas
//Constantes precisam ter nomes significativoos
//Não pode começar o nome de uma constante com um número
//Não pode conter espaços ou traços
// Utilizamos camelCase
//Case-sensitive
// Não pode modificar o valor de uma constante
//NÃO UTILIZE VAR, UTILIZE CONST.

const primNumero = 5;
const segNum = 10;
const resultado = primNumero * segNum
const resultadoDuplicado = resultado* 2
let resultadoTriplicado = resultado* 3
resultadoTriplicado = resultadoTriplicado +5

console.log(resultado)
console.log(resultadoDuplicado)
console.log(resultadoTriplicado)
