/*
Luiz Otavio Miranda tem 30 anos, pesa 84 kg
tem 1.80 de altura e seu IMC é de 25.92

ano de nascimenot 
*/

const nome = 'Maria Elisa'
const sobrenome = 'Lima França'
const idade = 23
const peso  =  100;
const altura = 1.80;

let imc ;
 imc = peso / (altura * altura)

let anoNasc;
anoNasc = 2024 - idade

/*
// Uma forma de fazer 
console.log(nome, sobrenome, 'tem', idade, 'anos, nasceu no ano', anoNasc, 'pesa', peso, 'kg');
console.log('tem', altura, 'de altura e seu IMC é de', imc)*/


// outra forma de fazer
 console.log(`${nome} ${sobrenome} tem ${idade}anos, nasceu no ano ${anoNasc}. Pesa, ${peso} kg`);
 console.log(`tem: ${altura} de altura e seu IMC é de ${imc}`)
